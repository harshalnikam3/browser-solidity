# Automatic build
Built website from `ab05933`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `browser-solidity-ab05933.zip`.
